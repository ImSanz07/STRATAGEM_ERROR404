let video=document.getElementById('webcam')
if(navigator.mediaDevices.getUserMedia) {
    navigator.mediaDevices.getUserMedia({video: true})
    .then (function(s) {
        video.srcObject=s;
    })
    .catch (function(err) {
        console.log(err);
    });
}