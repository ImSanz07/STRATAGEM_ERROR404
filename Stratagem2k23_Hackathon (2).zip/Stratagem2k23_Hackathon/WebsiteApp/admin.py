from django.contrib import admin
from .models import new_user

admin.site.register(new_user)

