from django.apps import AppConfig

class WebsiteAppConfig(AppConfig):
    default_auto_field='django.db.models.BigAutoField'
    name='WebsiteApp'