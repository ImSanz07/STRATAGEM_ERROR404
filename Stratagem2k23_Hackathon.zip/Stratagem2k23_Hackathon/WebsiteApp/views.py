from django.shortcuts import render, HttpResponse
from .models import new_user

# Create your views here.

def home(request):
    return render(request, 'index.html')

def signup(request):
    if request.method == 'POST':
        print(request.POST)
        username=request.POST['username']
        email=request.POST['email']
        password=request.POST['password']
        user=new_user(username=username, email=email, password=password)
        user.save()
        return render(request, 'index.html')
    else:
        return render(request, 'signup.html')
    

